#!/bin/bash
# /usr/local/sbin/rsyslog-agregation-purge.sh  (agrégateur ehlpj1fr)
# Compression et purge des fichiers d'une minute reçus des clients.

BASE=/data/rsyslog
COMPRESS_AFTER_MIN=5     # un fichier non modifié depuis 5 min est terminé
RETENTION_MIN=1440       # rétention : 24 h (en minutes)
LOCK=/var/run/rsyslog-agregation-purge.lock

exec 9>"$LOCK"
flock -n 9 || exit 0

[ -d "$BASE" ] || exit 0

find "$BASE" -type f -name '*.log' -mmin +"$COMPRESS_AFTER_MIN" -exec gzip -q {} \;
find "$BASE" -type f -name '*.log.gz' -mmin +"$RETENTION_MIN" -delete
